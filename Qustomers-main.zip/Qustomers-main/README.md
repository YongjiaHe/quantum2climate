Womanium Quantum Hackathon challenge 2022

# Team Name: Qustomers

# Team Member Details: 

  1. Dinesh Vishnu Kumar C , discord id : Dinesh Vishnu Kumar C#6351
  2. Kalai Ramea , discord id: Kalai#2645
  3. Yongjia He , discord id: Yongjia_He#0696
  4. Amit Kumar Singh, discord id: amit singh#2143, github id: amitQ22, email : amitsingharrah@gmail.com
  5. Perminder , discord id: perminder#9674
  
# Name of the Challenge : Green-Qupermarket-Technical-Focus---Deloitte

# Hack Solution Details :
  

