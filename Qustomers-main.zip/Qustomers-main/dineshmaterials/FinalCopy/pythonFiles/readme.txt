step 1) pip install -r requirements.txt
step 2) to open the notebook, place the notebook in a directory /dir:
jupyter notebook /dir/DeloitteQuperMarketDataRetreival__MallBatteryResetWeeklyBasis.ipynb
step 3) open the notebook file, change the directory of the car and weather data file.
Note:**Please use the car.xlsx from the respository as I have introduced 2 new columns for better optimization.